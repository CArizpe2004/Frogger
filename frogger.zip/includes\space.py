class Space:
    def __init__(self, xpos, ypos):
        self.xpos = xpos
        self.ypos = ypos
        self.WIDTH = 48
        self.HEIGHT = 60